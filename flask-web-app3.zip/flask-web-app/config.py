import os

class Config:
    SECRET_KEY = 'sih2019-samaritans-apollo'
    # MONGO_URI = 'mongodb+srv://keyur:keyur123@cluster0-5ay5y.mongodb.net/Cluster0?retryWrites=true'
    MONGO_URI = 'mongodb+srv://athnus:QWERTYUIOP@apollo-yhrx4.mongodb.net/em?retryWrites=true'
    # GOOGLEMAPS_KEY = 'AIzaSyC_qEvLL6iREFnrC3y1hQYvCggj7RsgRSw'
